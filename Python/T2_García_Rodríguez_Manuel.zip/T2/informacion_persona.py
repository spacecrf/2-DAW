persona = ("Manuel", 20, "Bollullos")
nombre, edad, cuidad = persona

print(f"Nombre: {nombre}")
print(f"Edad: {edad}")
print(f"Ciudad: {cuidad}")

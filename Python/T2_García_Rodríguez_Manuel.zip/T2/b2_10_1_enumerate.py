
nombres = ["Ana", "Luis", "Marta", "Carlos"]

for indice, nombre in enumerate(nombres):
    print(indice, nombre)

resultado = list(enumerate(nombres))
print(resultado)

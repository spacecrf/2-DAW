

<?php $__env->startSection('cuerpo'); ?>
<div style="background: #fccfcc; margin:1em; border:1px solid #999; border-radius:5px; margin:1em 5em">
    <?php echo e($descripcion); ?>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\_Profesor - 2022-23\2DAW-DWES\UT\1Ev\6 - UT 4 - Desarrollo de aplicaciones Web utilizando código embebido\Ejemplos\tareas_slim_session-v1\view/msg.blade.php ENDPATH**/ ?>
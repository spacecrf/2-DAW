

<?php $__env->startSection('cuerpo'); ?>
<h1>Nuestra página de inicio</h1>

<p>Página inicio que no hace nada</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\_Profesor - 2022-23\2DAW-DWES\UT\1Ev\6 - UT 4 - Desarrollo de aplicaciones Web utilizando código embebido\Ejemplos\tareas_slim_session-v1\view/inicio.blade.php ENDPATH**/ ?>
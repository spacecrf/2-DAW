<div style="float:left; width:8em; border-radius: 5px; border:1px solid #aaa; background: #ccffcc; margin-right: 1em;">
    <ul>
        <li><a href="<?php echo e(BASE_URL); ?>">Inicio</a></li>
        <li><a href="<?= BASE_URL ?>pag1">Pag. 1</a></li>
        <li><a href="<?= BASE_URL ?>listar">Listar</a></li>
        <li><a href="<?= BASE_URL ?>add">Alta</a></li>
        <li><a href="<?= BASE_URL ?>logout">Logout</a></li>
    </ul>
</div>
<?php /**PATH C:\_Profesor - 2022-23\2DAW-DWES\UT\1Ev\6 - UT 4 - Desarrollo de aplicaciones Web utilizando código embebido\Ejemplos\tareas_slim_session-v1\view/menu.blade.php ENDPATH**/ ?>
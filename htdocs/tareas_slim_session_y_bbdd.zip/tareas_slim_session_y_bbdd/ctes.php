<?php
if (!defined('APP_PATH')) {
    define('APP_PATH', __DIR__.'/');
    define('CTRL_PATH', __DIR__.'/ctrl/');
    define('MODEL_PATH', __DIR__.'/model/');
    define('VIEW_PATH', __DIR__.'/view/');
    define('CACHE_PATH', __DIR__.'/cache/');
    define('HELPERS_PATH', __DIR__.'/helpers/');
}
@extends('_template')

@section('cuerpo')
<div style="background: #fccfcc; margin:1em; border:1px solid #999; border-radius:5px; margin:1em 5em">
    {{$descripcion}}
</div>

@endsection
